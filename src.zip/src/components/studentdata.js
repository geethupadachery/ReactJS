import React from "react";
import DisplayStudentDetailsCopy from "../containers/DisplayStudentDetailsCopy";

const StudentData = ({ studentData }) => {
  return (
    <div>
      <center>
        <h1>Applicant Information</h1>
      </center>
      <div class="card">
        <div class="card-body">
          <h5 class="card-title">{studentData.firstName}</h5>
          <h5 class="card-title">{studentData.lastName}</h5>
          <h5 class="card-text">{studentData.username}</h5>
          <h5 class="card-text">{studentData.dateOfBirth}</h5>
          <h5 class="card-text">{studentData.about}</h5>
          <h5 class="card-text">{studentData.programs}</h5>
        </div>
      </div>
    </div>
  );
};

export default StudentData;
