import React, { Component } from "react";
import StudentData from "../components/studentdata";

class DisplayStudentDetailsCopy extends Component {
  constructor() {
    super();
    this.state = {
      studentData: []
    };
  }
  componentDidMount() {
    fetch(
      'https://ygnr0sm77e.execute-api.us-west-1.amazonaws.com/development/student/?username="apple"'
    )
      .then(Response => Response.json())
      .then(findresponse => {
        console.log(findresponse);
        this.setState({
          studentData: findresponse
        });
      })
      .catch(console.log);
  }

  render() {
    return <StudentData studentData={this.state.studentData} />;
  }
}

export default DisplayStudentDetailsCopy;
